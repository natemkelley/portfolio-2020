<template>
  <div>
    <div class="sky-container" ref="sky"></div>
    <div class="nature-container" ref="nature"></div>
    <div class="objects-container" ref="objects">
      <img src="@/assets/nba-ball.png" ref="testobj" />
    </div>
    <div class="immediateRatio-container" ref="immediateRatio"></div>
    <div class="ground-container" ref="ground">
      <Ground class="ground-item" ref="grass" />
    </div>
  </div>
</template>

<script>
import Ground from "~/assets/inlinesvg/Ground_Grass.svg?inline";
export default {
  name: "Grass",
  components: { Ground },
  mounted() {
    console.log("grass mounted");
  },
  methods: {
    initLayers() {
      this.$refs.ground.style.marginBottom =
        this.initialGroundElevationGround + "px";
      let totalWidth = this.$refs.grass
        .getAttribute("viewBox")
        .split(/\s+|,/)[2];
    }
  }
};
</script>