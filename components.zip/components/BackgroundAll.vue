<template>
  <div>
    <Grass />



    
    <div class="sky-container" ref="sky">
    </div>
    <div class="nature-container" ref="nature"></div>
    <div class="objects-container" ref="objects">
      <img src="@/assets/nba-ball.png" ref="testobj" />
    </div>
    <div class="immediateRatio-container" ref="immediateRatio"></div>
    <div class="ground-container" ref="ground">
      <Ground class="ground-item" ref="grass" />
      <Sea class="ground-item" ref="sea" />
    </div>
  </div>
</template>

<script>
import anime from "animejs";
import Grass from "~/components/backgrounds/Grass.vue"
import Ground from "~/assets/inlinesvg/Ground_Grass.svg?inline";
import Sea from "~/assets/inlinesvg/Ground_Sea.svg?inline";

/*
Sky Svg needs to be 1/6 the size of ground
Nature needs to be 1/4
objects needs to be 1/2
immediateRatio need to be 1/1
*/

export default {
  name: "BackgroundAll",
  components: { Ground, Sea, Grass },
  data() {
    return {
      skyMovementRatio: 6,
      objectMovementRatio: 1.15,
      natureMovementRation:1.75,
      immediateRatio: 1,
      testobjpos: 1084
    };
  },
  props: [
    "previousScrollPos",
    "groundElevationGround",
    "initialGroundElevationGround",
    "offsetLeft"
  ],
  mounted() {
    this.initLayers();
    this.calculateAndEmitPageHeight();
    this.handleMovement(0); //positions objects on page
  },
  methods: {
    initLayers() {
      this.$refs.ground.style.marginBottom =
        this.initialGroundElevationGround + "px";
      let totalWidth = this.$refs.grass
        .getAttribute("viewBox")
        .split(/\s+|,/)[2]; //width of grass

      /*this.$refs.sea.style.marginLeft = totalWidth + "px";
      totalWidth += this.$refs.sea
        .getAttribute("viewBox")
        .split(/\s+|,/)[2];*/
    },
    calculateAndEmitPageHeight() {
      var items = this.$el.querySelectorAll(".ground-item");
      var totalHeight = 0;
      items.forEach(element => {
        totalHeight += Number(
          element.getAttribute("viewBox").split(/\s+|,/)[2]
        );
      });
      this.$emit("informheight", totalHeight); //shorten actual emit
    },
    handleMovement(value) {
      //ground
      this.$refs.ground.style.marginLeft = `${-value + "px"}`;

      //sky
      this.$refs.sky.style.marginLeft = `${-value / this.skyMovementRatio +
        "px"}`;

      //objects
      let multiplier = 1 / this.objectMovementRatio - 1; //0
      let offset = this.testobjpos - 70 - this.offsetLeft - value;
      let moveval = multiplier * offset;
      this.$refs.testobj.style.marginLeft =
        moveval - value + this.testobjpos + "px";
    },
    handleMovementY(value) {
      console.log("y value", value);
      anime({
        targets: this.$refs.ground,
        translateY: -value,
        easing: "cubicBezier(.4,.06,.82,.37)",
        duration: 300,
        delay: 0,
        begin: () => {
          console.log("starting ground");
        },
        complete: anim => {
          console.log("complete ground");
        }
      });
    }
  },
  watch: {
    previousScrollPos(newVal) {
      this.handleMovement(newVal);
    },
    groundElevationGround(newVal, oldVal) {
      console.log("ground", newVal, oldVal);
      this.handleMovementY(newVal);
    }
  }
};
</script>

<style scoped>
.ground-container {
  position: fixed;
  bottom: 0;
  left: 0;
}

.ground-item {
  position: absolute;
  bottom: 0;
  left: 0;
}

.sky-container {
  position: fixed;
  top: 0;
  left: 0;
}

.sky-item {
  position: absolute;
  top: 0;
  left: 0;
}

.objects-container {
  position: fixed;
  top: 0;
  left: 0;
}

.objects-container img {
  margin-top: 70vh;
  z-index: 9999;
}
</style>